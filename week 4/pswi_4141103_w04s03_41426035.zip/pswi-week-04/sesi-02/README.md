Nama:Cristiano david
NIM :41426035
Prodi: DIV-TRPL

pengamatan stylesheet ==> latar halaman web berubah menjadi code yang sudah kita masukkan di style.css

catatan pengujian pengubahan class ==> ketika saya mengubah sementara nama class, hasilnya ketika me running di browser code yang sudah di buat di style.css tidak di jalankan di halaman web yang kita buat.

pengamatan kenapa .card p lebih spesifik karena .card p  memilih semua <p> yang berada di elemen class card

pengamatan terhadap ukuran kotak ==> tidak ada perubahan setelah di ubah 

FORMAT LAPORAN YANG DI ISI MAHASISWA
kasus: style.css tidak merespon
tindakan: saya menambahkan <link rel="stylesheet" href="CSS/style.css"> pada index.html
setelah di uji: hasilnya style.css di jalankan juga ke halaman web nya yang mau di dekorasi
status/bukti: dapat di lihat di halaman web ini

kasus: .card pada style.css yang tidak bekerja pada class="card" ketika sudah di jalankan di halaman web
tindakan: saya memindahkan kurung kurawal milik button ke tempat yanng sesuai setelah di uji: .card jadi dapat berperan dalam halaman web  
status/bukti: warna dari teks "petunjuk" dan "Contoh: 001234. Gunakan tepat enam angka" jadi berubah sesuai yang di harapkan

kasus: mengubah margin dengan cara lain 
tindakan: mengubah margin menjadi "margin: 240+32+4;" 
setelah di uji:tak ada perubahan
status/bukti:dapat di lihat melalui halaman web di bagian card nya

AI statement:
saya menggunakan AI pada projek ini untuk memberikan saya arahan jika saya tidak memahami setiap error ataupun fungsi dari tag-tag yang saya buat