validasi CSS ==> sebelum: peletakan dalam kurung kurawal pada css saya bermasalah di bagian jumlahnya yang kelebihan
                 sesudah: saya mengurangi dalam kurung kurawal

kasus normal: tidak ada
Tindakan: tidak ada
Hasil aktual: tidak ada
Status/bukti: tidak ada

kasus batas: main di style.css 
Tindakan: jika saya membuat batas max-width, maka width akan mengikuti batas maksimal nya
Hasil aktual: halaman web di bagian main jadi berubah ukuran sesuai width yang di atur
Status/bukti: dapat di lihat dari halaman web ini di bagian head dan body nya memiliki ukuran yang berbeda

kasus gagal:  pada bagian "button:focus-visible,
input:focus-visible {
outline: 3px solid var(--brand);
outline-offset: 3px;" }" tidak ada merubah apapun pada halaman web
Tindakan: tidak ada
Hasil aktual: tidak ada
Status/bukti: halaman web tidak ada yang berbeda dari sebelum dan sesudah dimasukkan nya "button:focus-visible,
input:focus-visible {
outline: 3px solid var(--brand);
outline-offset: 3px;" }"

AI use statement:
saya menggunakan AI pada projek ini yang bertujuan untuk memberikan saya arahan jika ada bagian yang kurang saya pahami, begitupun dengan error yang kurang saya pahami dan tidak hanya menyalin code dengan instan

