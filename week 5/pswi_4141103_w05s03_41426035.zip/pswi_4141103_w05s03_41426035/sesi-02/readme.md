Laporan uji row lalu column ==> ketika saya mengecilkan layar halaman web dengan wrap, hasilya id kontak dan kegiatan berpindah kebawah 

hasil pengujian card fleksibel  pada 360px dan 1200px ==> bagian cards jadi berubah mengecil dan semakin besar jumlah pixel yang saya buat, maka semakin kecil juga isi dari cards tersebut

hasil uji overflow wrap ==> dengan menggunakan overflow wrap, teks yang panjang tidak akan terpotong jika layar halaman web mengecil 


                                                    FORMAT LAPORAN YANG DI ISI MAHASISWA

kasus normal: hasil saat mengecil kan layar tanpa menggunakan wrap pada bagian id, membuat id tidak berpindah ke bawah saat mengecilkan layar halaman web
tindakan: Memasang wrap untuk bagian id kegiatan dan kontak
setelah di uji: id kegiatan dan kontak berpindah ke bawah
status/bukti: dapat di lihat melalui gambar pada folder bukti

kasus batas: teks yang panjang pada bagian class card tidak berpindah kebawah tanpa overflow wrap 
tindakan: saya memasukkan overflow wrap ke bagian class card
setelah di uji: teks panjang jadi tetap rapi di dalam card
status/bukti: dapat di lihat pada SS overlay

kasus gagal: tidak ada
tindakan: -
setelah di uji: -
status/bukti:-

AI statement:
saya menggunakan AI pada projek ini untuk memberikan saya arahan jika saya tidak memahami setiap error ataupun fungsi dari tag-tag yang saya buat