1. pada bagian mengubah container ==> hasilnya muncul dua kolom pada halaman webnya

2. jumlah kolom dengan menambahkan item kelima ==> tetap menjadi 3 kolom, hasilnya dapat di lihat di ss bukti  

                                                 
                                                 FORMAT LAPORAN YANG DI ISI MAHASISWA

kasus normal: tampilan dengan ukuran layar standar (768px) dan jumalah card (3)
tindakan: mengembalikkan ukuran ke 15rem
setelah di uji: cards kembali ke bentuk semula
status/bukti: dapat di lihat melalui gambar pada folder bukti

kasus batas: layar sangat kecil (320px) atau hanya ada 1 card
tindakan: balikkan lagi menjadi 15rem pada catalog
setelah di uji: jumlah cards kembali semula
status/bukti: dapat di lihat pada SS bukti

kasus gagal: tidak ada perubahan pada gap di .card
tindakan: mengubah angka pada rem menjadi 100rem
setelah di uji: tidak ada yang berubah
status/bukti: halaman web pada bagian card tetap rapat

AI statement:
saya menggunakan AI pada projek ini untuk memberikan saya arahan jika saya tidak memahami setiap error ataupun fungsi dari tag-tag yang saya buat