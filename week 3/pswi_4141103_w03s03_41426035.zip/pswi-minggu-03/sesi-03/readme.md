ketika saya menguji 0,1,2,3,4,5 dan 1,5 hasil dari 1-5 semuanya bisa di masukkan dan hasilnya sama. Sedangkan, jika saya mencoba memasukkan 0 dan 1,5 langsung muncul pemberitahuan kalau no tersebut tidak dapat di masukkan

Kasus Harapan:
Email kosong Ditolak karena required
Email abc Ditolak karena bentuk email
Email contoh valid Diterima jika lainnya valid
Jumlah 0 / 6 Ditolak
Jumlah 1 / 5 Diterima
Jumlah 1.5 Ditolak bila step=1
Kode 12345 Ditolak
Kode 001234 Diterima
Keyboard Semua kontrol dapat dicapai
(Semuanya berjalan sesuai harapan)

server tetap perlu memvalidasi agar tidak terjadi error atau bug dalam halaman web yang kita buat, sehingga pengguna tidak kesusahan saat menggunakan halaman web yang kita sediakan

sumber gambar:
https://th.bing.com/th/id/R.24cf382021bfe9827cfec5d94031b1b3?rik=5%2bYZe6jtRQ6P6A&riu=http%3a%2f%2friyanthisianturi.com%2fwp-content%2fuploads%2f2020%2f04%2fRiyanthi_Sianturi_Institut_Teknologi_Del_08.jpg&ehk=s2xkIoQg0fOY5zRMQ76F2mb4Zvju%2bOl%2f5G9Ks70PRMU%3d&risl=&pid=ImgRaw&r=0

AI statement:
saya menggunakan AI pada project ini yang bertujuan untuk memberikan saya arahan bila ada error dan bagian yang kurang saya pahami, bukan kode yang siap di salin.