Peran dari:
1. id adalah untuk mengidinetifikasi elemen ketika di sambungkan dengan fragmen id
2. name untuk memasukkan nama para pengguna ketika sudah di isi
3. type untuk tempat pengisian dan digunakan sebagai tombol

Lurinng:
nama=wowok&email=sawit%40gmail.com&prodi=trpl&mode=luring&catatan=Hidup...

Daring:
nama=Mamang&email=Garox%40gmail.com&prodi=trpl&mode=daring&catatan=Gua+lagi+stay+di+sini

ESKPERIMEN TERARAH :
setelah saya menghapus name pada input name, hasilnya pasangan kontrol tidak dapat tampil ketika di jalankan
selanjutnya, saya mendisabled name sehingga namanya tidak dapat di isi.

 Ketika dijalankan dan hanya Radio yang dipilih hasilnya, hanya nilai pilihan aktif tampil

Pertanyaan Laporan :
1) Mengapa telepon bukan kuantitas number?
Jawaban, karena nomor telepon bukanlah angka yang digunakan dalam hitungan melainkan sebuah informasi.

2) Apa beda label pilihan dan legend kelompok?
Jawaban, label digunakan untuk menjelaskan satu input atau kontrol dalam suatu program sedangkan legend yang digunakan untuk menjelaskan sekelompok kontrol dalam program.

3) Apa beda id dan name?
Jawaban, id digunakan untuk memberikan identitas unik dalam nama HTML dan digunakan oleh label sedangkan name adalah untuk memberikan nama file yang akan di kirimkan.

4) Apa yang terjadi pada checkbox tidak dicentang ?
Jawaban, checkbox yang tidak dicentang tidak akan mengirim datanya saat di submit hanya checkbox yang di centang yang akan dikirim.

AI Statement:
saya menggunakan AI pada proyek yang saya kerjakann ini, yg bertujuan untuk memberikan pemahaman dan arahan jika ada error atau bagian yang sulit dipahami