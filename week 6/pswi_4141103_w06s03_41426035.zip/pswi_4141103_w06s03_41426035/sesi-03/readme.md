1) Uji gambar fleksibel
Tindakan            : Saya menambahkan css dengan max width dan height pada gambar di html
Hasil               : Ketika layar halaman web mengecil, gambar ikut menyesuaikan dengan layar
Bukti               : Dapat di lihat pada folder bukti
Sumber gambar:
1. Starry Night (https://www.google.com/url?sa=t&source=web&rct=j&url=https%3A%2F%2Fid.wikipedia.org%2Fwiki%2FBerkas%3AVan_Gogh_-_Starry_Night_-_Google_Art_Project.jpg&ved=0CBcQjRxqFwoTCNiJn5-AvpcDFQAAAAAdAAAAABA4&opi=89978449)
2. Karya seni Neo-klasik (https://www.google.com/url?sa=t&source=web&rct=j&url=https%3A%2F%2Fsenirupasmasa.wordpress.com%2F2013%2F03%2F01%2Fneoklasik-dan-romantisme%2F&ved=0CAQQjB1qFwoTCIjlksmCvpcDFQAAAAAdAAAAABA4&opi=89978449)
3. Karya seni penghianatan Julius Caesar (https://www.google.com/imgres?q=Karya%20seni%20penghianatan%20Julius%20Caesar&imgurl=https%3A%2F%2Fthumb.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2Fe%2Feb%2FVincenzo_Camuccini_-_La_morte_di_Cesare.jpg%2F1280px-Vincenzo_Camuccini_-_La_morte_di_Cesare.jpg%3Futm_source%3Did.wikipedia.org%26utm_campaign%3Dindex%26utm_content%3Dthumbnail&imgrefurl=https%3A%2F%2Fid.wikipedia.org%2Fwiki%2FKematian_Julius_Caesar_(Camuccini)&docid=1CvDzlGkaggtSM&tbnid=iNwuHeLxXK4ZnM&vet=12ahUKEwiS6eeHg76XAxUH-jgGHXD3AMYQnPAOegQIPxAA..i&w=1280&h=726&hcb=2&ved=2ahUKEwiS6eeHg76XAxUH-jgGHXD3AMYQnPAOegQIPxAA)
4. Mixed Flowers in an Earthenware Pot (1869) (https://www.google.com/imgres?q=Karya%20seni%20penghianatan%20Julius%20Caesar&imgurl=https%3A%2F%2Fthumb.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2Fe%2Feb%2FVincenzo_Camuccini_-_La_morte_di_Cesare.jpg%2F1280px-Vincenzo_Camuccini_-_La_morte_di_Cesare.jpg%3Futm_source%3Did.wikipedia.org%26utm_campaign%3Dindex%26utm_content%3Dthumbnail&imgrefurl=https%3A%2F%2Fid.wikipedia.org%2Fwiki%2FKematian_Julius_Caesar_(Camuccini)&docid=1CvDzlGkaggtSM&tbnid=iNwuHeLxXK4ZnM&vet=12ahUKEwiS6eeHg76XAxUH-jgGHXD3AMYQnPAOegQIPxAA..i&w=1280&h=726&hcb=2&ved=2ahUKEwiS6eeHg76XAxUH-jgGHXD3AMYQnPAOegQIPxAA)

2) KANDIDAT RESOLUSI
Tindakan        : Masukkan srcset pada html gambar pada masing-masing card dan saya mengaktifkan disabled cache
Hasil           : Gambar mengikuti ukuran layar yang di atur dan semua ukuran nya sama dan kandidat benar tersedia dan dipilih browser
Bukti           : dapat di lihat melalui folder bukti atau cek langsung dari halaman web ini dengan membua devtools 

3) FLUID FONT DAN CONTAINER QUERY
Perbedaan query:hanya menyesuaikan css sesuai ukuran layar
Tindakan       :Saya menambahkan container query pada judul h1
Hasil          :Judul pada ukuran perlahan mengecil/membesar ketika layar halaman web di ubah-ubah
Bukti          : Dapat di lihat pada folder bukti atau melalui halaman web nya langsung ketika di perbesar atau diperkecil

4) REDUCED MOTION DAN AUDIT
Tindakan       : Tambahkan prefers-reduced-motion untuk mengaktifkan opsi “reduce motion”
Hasil          : Maka semua transisi/animasi di .card akan dimatikan.
Bukti          : Dapat di lihat melalui folder bukti atau di uji melalui halamn web ini langsung
